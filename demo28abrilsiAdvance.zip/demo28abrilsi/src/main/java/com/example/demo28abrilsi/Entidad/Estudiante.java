package com.example.demo28abrilsi.Entidad;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

import java.util.Set;

@Entity
@Table(name = "estudiante")
public class Estudiante {
    @Id //:LLave primaria

    //longitud de la variable:
    @Column(length = 30)
    private String documento;
    @Column(nullable = false,length = 50)
    private String nombre;
    @Column(nullable = false,length = 50)
    private String apellido;
    @Column(nullable = false,length = 50,unique = true)
    private String correo;
    @Column(nullable = false,length = 50)
    private String telefeno;

    //Atributo para las relaciones://Cascade:Eliminar los datos en cascada de sus metodos ToString//Fetch: para nombre de las columnas despues llamarlas
    @OneToMany(mappedBy = "estudiante",cascade = CascadeType.ALL,fetch = FetchType.LAZY)//"estudiante(llave foranea)", es para realizar lo que son las relaciones de uno a muchos
    private Set<Prestamo> prestamo ;//set= llama los datos de la entidad de Estudiante




    public Estudiante() {
    }

    public Estudiante(String documento, String nombre, String apellido, String correo, String telefeno) {
        this.documento = documento;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.telefeno = telefeno;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefeno() {
        return telefeno;
    }

    public void setTelefeno(String telefeno) {
        this.telefeno = telefeno;
    }


    public Set<Prestamo> getPrestamo() {
        return prestamo;
    }

    public void setPrestamo(Set<Prestamo> prestamo) {
        this.prestamo = prestamo;
    }

    @Override
    public String toString() {
        return "Estudiante{" +
                "documento='" + documento + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", correo='" + correo + '\'' +
                ", telefeno='" + telefeno + '\'' +
                '}';
    }
}
