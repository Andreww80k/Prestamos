package com.example.demo28abrilsi.Entidad;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.Date;
@Entity
@Table(name = "prestamo")
public class Prestamo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)//Generar los valores
    private Integer id_prestamo;
    @Column(name = "fecha")//Mapeamos columna de fecha
    @Temporal(TemporalType.DATE)//Registra las fechas actuales(Campo para las fechas)


    private Date fecha;
    //Llaves foranea del libro y de estudiante
    //llamamos a la entidad estudiante

    //RELACION DE MUCHOS A UNOOOOOO:
    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    //Relacion entre columnas
    @JoinColumn(name = "documento",referencedColumnName = "documento",nullable = false)
    @JsonIgnore


    private Estudiante estudiante;
    @ManyToOne(fetch = FetchType.LAZY,optional = false)
    //Relacion entre columnas
    @JoinColumn(name = "isbn",referencedColumnName = "isbn",nullable = false)
    @JsonIgnore

    private Libro libro;
    //Metodo para la fecha actual para las bases de datos
    @PrePersist//Significa antes de guardar para las fechas()
    public void fechaActual(){
        this.fecha= new Date();
    }


    public Prestamo() {
    }

    public Prestamo(Integer id_prestamo, Date fecha, Estudiante estudiante, Libro libro) {
        this.id_prestamo = id_prestamo;
        this.fecha = fecha;
        this.estudiante = estudiante;
        this.libro = libro;
    }

    public String getId_prestamo() {
        return id_prestamo;
    }

    public void setId_prestamo(Integer id_prestamo) {
        this.id_prestamo = id_prestamo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }

    @Override
    public String toString() {
        return "Prestamo{" +
                "id_prestamo=" + id_prestamo +
                ", fecha=" + fecha +
                ", estudiante=" + estudiante +
                ", libro=" + libro +
                '}';
    }
}
