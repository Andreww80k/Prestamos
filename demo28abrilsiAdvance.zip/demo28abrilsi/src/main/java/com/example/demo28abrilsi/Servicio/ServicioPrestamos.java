package com.example.demo28abrilsi.Servicio;


import com.example.demo28abrilsi.Entidad.Libro;
import com.example.demo28abrilsi.Entidad.Prestamo;
import com.example.demo28abrilsi.Repositorio.RepositorioPrestamos;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;

@Service
public class ServicioPrestamos {


    //Repositorio como atributo para realizar los distintos procedimientos


    private RepositorioPrestamos repositorio;


    public ServicioPrestamos(RepositorioPrestamos repositorio){
        this.repositorio=repositorio;
    }


    //Ejmplo de un servicio


    //Para listar o encontrar prestamos de cierta manera, vamos a consultarlos por los siguientes metodos

    public ArrayList<Prestamo>listarPrestamos(){
        return (ArrayList<Prestamo>) repositorio.findAll();
    }



    //Metodo de buscar prestamos por Jpa



    public ResponseEntity<?> agregarPrestamo(@RequestBody Prestamo prestamo) {
        if (repositorio.findById(prestamo.getId_prestamo()).isPresent()) {
            return ResponseEntity.badRequest().body("El prestamo ya se encuentra registrado.");
        } else {
            Prestamo nuevoPrestamo = repositorio.save(prestamo);
            return ResponseEntity.ok().body(nuevoPrestamo);
        }
    }


    public String actualizarPrestamo(Prestamo prestamo){

        //pregunta si existe para actualizar:


        if (repositorio.findById(prestamo.getId_prestamo()).isPresent()){
            repositorio.save(prestamo);
            return "El Prestamos se actualizo exitosamente";
        }

    else {
        return "El prestamos no se encuentra registrado actualmeente";
        }
    }


    //Para Eliminar:

    public String eliminarPrestamos(int id){
        if (repositorio.findById(String.valueOf(id)).isPresent()){
            repositorio.deleteById(String.valueOf(id));
            return "Prestamo eliminado";
        }
        else {
            return "Ahora el prestamo no se encuentra registrado previamente";
        }
    }


    //Para actualizar
    public  String ActualizarPrestamos(Prestamo prestamo){
        //pregunta si existe:

        if (repositorio.findById(prestamo.getId_prestamo()).isPresent()){
            repositorio.save(prestamo);

            return "El prestamo se actualizo exitosamente ";
        }
        else{
            return"El prestamo no se encuentra registrado actualmente";
        }
    }


    public  String eliminarPrestamo(String id){
        if (repositorio.findById(id).isPresent()){
            repositorio.deleteById(id);
            return "Prestamo  eliminado";
        }
        else{
            return "Ahora el prestamo  no se encuentra registrado";
        }
    }





}
