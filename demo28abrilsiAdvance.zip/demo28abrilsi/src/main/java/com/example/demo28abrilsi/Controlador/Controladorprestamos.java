package com.example.demo28abrilsi.Controlador;


import com.example.demo28abrilsi.Entidad.Prestamo;
import com.example.demo28abrilsi.Servicio.ServicioPrestamos;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
public class Controladorprestamos {

    //Para insanticar la clase


    private ServicioPrestamos service;

    public Controladorprestamos(ServicioPrestamos service) {
        this.service = service;
    }


    //Crera la ruta que retorne a un arraylist


    @GetMapping("/listarPrestamos")
    public ArrayList<Prestamo> listarpPrestamos() {
        return service.listarPrestamos();
    }


    //Crear un metodo de controlador para Agregar un nuevo prestamso

    @GetMapping("/agregarPrestamo")
    public ResponseEntity<?> agregarPrestamo(@RequestBody Prestamo prestamo) {

        return service.agregarPrestamo(prestamo);
    }


    //Metodo de actualizar:
    @PutMapping("/ActualizarPrestamos")
    public String ActualizarPrestamos(@RequestBody Prestamo prestamo) {
        return service.ActualizarPrestamos(prestamo);
    }

    //Eliminar:


    @DeleteMapping("/eliminarPrestamo/{id}")
    public String eliminarPrestamo(@PathVariable("")String id){
        return service.eliminarPrestamo(id);
    }

}
