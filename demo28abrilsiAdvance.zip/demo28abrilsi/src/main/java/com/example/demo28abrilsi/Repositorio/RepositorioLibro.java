package com.example.demo28abrilsi.Repositorio;

import com.example.demo28abrilsi.Entidad.Libro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;

@Repository

//Sirve para manejar  libros
public interface RepositorioLibro extends  JpaRepository<Libro,String> {
}
