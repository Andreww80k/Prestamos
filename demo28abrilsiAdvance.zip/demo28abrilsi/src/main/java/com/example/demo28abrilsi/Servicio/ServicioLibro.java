package com.example.demo28abrilsi.Servicio;


import com.example.demo28abrilsi.Entidad.Libro;
import com.example.demo28abrilsi.Repositorio.RepositorioLibro;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ServicioLibro {

    //Repositorio como atributo

    private RepositorioLibro repositorio;

    public ServicioLibro(RepositorioLibro repositorio) {
        this.repositorio = repositorio;
    }


    //Ejemplo de listar libros:

    //Para listrar o encontrar libros, en este caso, consultar todos los clientes de una tabla


    //Entidades que se utilizan a continuacion:

    public ArrayList<Libro> listarLibros() {
        return (ArrayList<Libro>) repositorio.findAll();
    }


    //Metodo buscar libro por jpa



    public  Libro buscarLibro(String isb){
        //Findby es para encontrar por un dato en especifico, buscando por llave primaria

        if (repositorio.findById(isb).isPresent())
            return repositorio.findById(isb).get();

        else return null;
    }

    public  String agregarLibro(Libro libro){

        //Pregunta si existe dicho libro:

        if (repositorio.findById(libro.getIsbn()).isPresent())
            return "El libro ya esta registrado en esta base de datos";

        else {
            repositorio.save(libro);
            return "El libro se registro satisfactoriamente";
        }
    }

    //para Actualizar:

    public  String actualizarLibro(Libro libro){
        //pregunta si existe:

        if (repositorio.findById(libro.getIsbn()).isPresent()){
            repositorio.save(libro);

            return "El libro se actualizo exitosamente ";
        }
        else{
            return"El libro no se encuentra registrado actualmente";
        }
    }

    //Para eliminar

    public  String eliminarLibro(String isb){
        if (repositorio.findById(isb).isPresent()){
            repositorio.deleteById(isb);
            return "Libro eliminado";
        }
        else{
            return "Ahora el libro no se encuentra registrado";
        }
    }
}
