package com.example.demo28abrilsi.Controlador;

import com.example.demo28abrilsi.Entidad.Estudiante;
import com.example.demo28abrilsi.Servicio.ServicioEstudiante;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
public class ControladorEstudiante {
    //Para instanciar la clase


    private ServicioEstudiante service;

    public ControladorEstudiante(ServicioEstudiante service){
        this.service=service;
    }



    //Crear ruta que retorne a un arraylist

    @GetMapping("/ListarEstudiantes")
    public ArrayList<Estudiante>ListarEstudiantes(){
        return service.ListarEstudiantes();
    }


    //Crear metodo de buscar

    @GetMapping("/BuscarEstudiante/{doc}")
    public Estudiante BuscarEstudiante(@PathVariable("doc")String documento){
        return service.BuscarEstudiante(documento);
    }

    //Metodo de agregar Estudiante
    @GetMapping("/AgregarEstudiante")
    public String AgregarEstudiante(@RequestBody Estudiante estudiante){
        return service.AgregarEstudiante(estudiante);
    }

    //Metodo de Actualizar Estudiante

    @PutMapping("/ActualizarEstudiante")
    public String ActualizarEstudiante(@RequestBody Estudiante estudiante){
        return service.ActualizarEstudiante(estudiante);
    }


    //Metodo de eliminar
    @DeleteMapping("/EliminarEstudiante/{doc}")
    public String EliminarEstudiante(@PathVariable("doc")String documento){
        return service.EliminarEstudiante(documento);
    }
}
