package com.example.demo28abrilsi.Entidad;

import jakarta.persistence.*;

import java.util.Set;

@Entity
@Table(name = "libro")//Creamos la tabla dentro de la base de datos
public class Libro {
    @Id
    @Column(length = 30)
    private String isbn;
    @Column(nullable = false,length = 50)
    private String titulo;
    @Column(nullable = false,length = 50)
    private String autor;
    @Column(nullable = false,length = 50)
    private String editorial;
    @Column(name = "no_page")
    private int no_pag;

    @OneToMany(mappedBy = "libro",cascade = CascadeType.ALL,fetch = FetchType.LAZY)//"libro(llave foranea)", es para realizar lo que son las relaciones de uno a muchos
    private Set<Prestamo> prestamo ;//set= llama los datos de la entidad de Libro


    public Libro() {
    }

    public Libro(String isbn, String titulo, String autor, String editorial, int no_pag) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.editorial = editorial;
        this.no_pag = no_pag;

    }


    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getNo_pag() {
        return no_pag;
    }

    public void setNo_pag(int no_pag) {
        this.no_pag = no_pag;
    }

    public Set<Prestamo> getPrestamo() {
        return prestamo;
    }

    public void setPrestamo(Set<Prestamo> prestamo) {
        this.prestamo = prestamo;
    }

    @Override
    public String toString() {
        return "Libro{" +
                "isbn='" + isbn + '\'' +
                ", titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", editorial='" + editorial + '\'' +
                ", no_pag=" + no_pag +
                '}';
    }
}
