package com.example.demo28abrilsi.Repositorio;



import com.example.demo28abrilsi.Entidad.Prestamo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository

// Sirve para manejar a los prestamos con sus relaciones

    public interface RepositorioPrestamos extends JpaRepository<Prestamo,String>{
}
