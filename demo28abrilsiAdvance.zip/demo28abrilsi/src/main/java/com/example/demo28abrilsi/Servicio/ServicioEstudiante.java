package com.example.demo28abrilsi.Servicio;


import com.example.demo28abrilsi.Entidad.Estudiante;
import com.example.demo28abrilsi.Repositorio.RepositorioEstudiante;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ServicioEstudiante {

    //Repositorio como un atributo

    private RepositorioEstudiante repositorio;


    public ServicioEstudiante(RepositorioEstudiante repositorio) {
        this.repositorio = repositorio;
    }


    //Ejemplo de un servicio

    //Para listar o encontrar clientes, en este caso se debe consultar los ESTUDIANTES de su tabla en si

    //Entidades necesarias:

    public ArrayList<Estudiante> ListarEstudiantes() {
        return (ArrayList<Estudiante>) repositorio.findAll();
    }


    //Metodo buscar Estudiante por Jpa

    public Estudiante BuscarEstudiante(String doc) {
        //FinById es para encontrar por un dato especifico, lo busca por llave primaria

        if (repositorio.findById(doc).isPresent())
            return repositorio.findById(doc).get();

        else return null;


    }

    //Metodo para agregar

    public String AgregarEstudiante(Estudiante estudiante) {
        //Pregunta si existe:


        if (repositorio.findById(estudiante.getDocumento()).isPresent())
            return "El Estudiante ya esta registrado, vuelva a rectificar";

        else {
            repositorio.save(estudiante);
            return "El Estudiante se ha registrado satisfactoriamente";
        }
    }


    public String ActualizarEstudiante(Estudiante estudiante) {
        //Pregunta si existe
        if (repositorio.findById(estudiante.getDocumento()).isPresent()) {
            return "El Estudiante se actualizo de forma exitosa";
        } else {
            return "El Estudiante no se encuentra registrado actualmente";
        }
    }


    //Para eliminar un estudiante

    public String EliminarEstudiante(String doc) {
        if (repositorio.findById(doc).isPresent()) {
            repositorio.deleteById(doc);
            return "Toma!! Estudiante eliminado";

        } else {
            return "En este momento el Estudiante no se encuentra registrado";
        }

    }
}