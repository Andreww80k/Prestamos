package com.example.demo28abrilsi.Controlador;

import com.example.demo28abrilsi.Entidad.Libro;
import com.example.demo28abrilsi.Servicio.ServicioLibro;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
public class ControladorLibro {
    //Instanciar la clase


    private ServicioLibro service;
    public  ControladorLibro (ServicioLibro service){
        this.service=service;
    }




    //Crear la ruta y retornar a un arraylist

    //Metodo de listar libros
    @GetMapping("/ListarLibros")
    public ArrayList<Libro>listarlibros(){
        return service.listarLibros();
    }


// Metodo de buscar libro
    @GetMapping("/buscarLibro/{isb}")
    public Libro buscarLibro(@PathVariable("isb")String isbn){
        return service.buscarLibro(isbn);
    }


    // Metodo de agregar libro
    @PostMapping("/agregarLibro")
    public String agregarCliente(@RequestBody Libro libro){
        return service.agregarLibro(libro);
    }


    //Actualizar Libro

    @PutMapping("/Actualizarlibro")
    public String Actualizarlibro(@RequestBody Libro libro){
        return service.actualizarLibro(libro);
    }


    //Eliminar libro

    @DeleteMapping("/eliminarLibro/{isb}")
    public String eliminarLibro(@PathVariable("")String isbn){
        return service.eliminarLibro(isbn);
    }


}
