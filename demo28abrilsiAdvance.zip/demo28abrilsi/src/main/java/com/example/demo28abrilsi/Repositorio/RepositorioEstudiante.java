package com.example.demo28abrilsi.Repositorio;

import com.example.demo28abrilsi.Entidad.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;


@Repository
    //Sirve para manejar los estudiantes

    public interface RepositorioEstudiante extends JpaRepository<Estudiante,String>{


        ArrayList<Estudiante> findBynombre(String nombre);

    }

