package com.example.demo28abrilsi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo28abrilsiApplicationTests {

	@Test
	void contextLoads() {
	}

}
